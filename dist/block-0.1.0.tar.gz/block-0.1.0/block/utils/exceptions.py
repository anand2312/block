# exceptions

class InternalException(Exception):
    pass