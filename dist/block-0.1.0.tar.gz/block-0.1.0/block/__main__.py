# running in `python -m  block` mode
import block.cli