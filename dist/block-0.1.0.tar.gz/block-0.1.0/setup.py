# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['block', 'block.core', 'block.utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'block',
    'version': '0.1.0',
    'description': 'Easily block yourself from accessing distracting websites.',
    'long_description': None,
    'author': 'Anand Krishna',
    'author_email': 'anandkrishna2312@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
